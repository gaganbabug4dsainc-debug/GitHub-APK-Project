package com.example.phoneagent

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.widget.TextView

/** Chhote UI helpers (app screens + floating panel dono me kaam aate hain). */
object Ui {
    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    fun circle(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    val GREY = Color.parseColor("#3C4043")
    val GREEN = Color.parseColor("#1E8E3E")
    val RED = Color.parseColor("#D93025")
    val BLUE = Color.parseColor("#1A73E8")

    fun chip(
        ctx: Context,
        label: String,
        bg: Int = GREY,
        fg: Int = Color.WHITE,
        size: Float = 12f,
        onClick: () -> Unit
    ): TextView = TextView(ctx).apply {
        text = label
        textSize = size
        setTextColor(fg)
        gravity = Gravity.CENTER
        setPadding(dp(ctx, 8), dp(ctx, 7), dp(ctx, 8), dp(ctx, 7))
        background = rounded(bg, dp(ctx, 14))
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        isClickable = true
        setOnClickListener { onClick() }
    }

    fun setChipColor(chip: TextView?, color: Int) {
        (chip?.background as? GradientDrawable)?.setColor(color)
    }
}
