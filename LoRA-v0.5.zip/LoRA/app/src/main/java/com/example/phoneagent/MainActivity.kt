package com.example.phoneagent

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private var recoveryShown = false
    }

    private lateinit var logView: TextView
    private lateinit var dash: TextView
    private lateinit var providersBox: LinearLayout
    private lateinit var tasksBox: LinearLayout
    private lateinit var modelBtn: Button
    private lateinit var langBtn: Button
    private lateinit var stepsField: EditText

    private val logListener: (String) -> Unit = { line ->
        runOnUiThread { logView.append(line + "\n") }
    }
    private val stateListener: () -> Unit = { runOnUiThread { refreshDashboard() } }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun heading(t: String) = TextView(this).apply {
        text = t
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(20), 0, dp(4))
    }

    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(Color.GRAY)
    }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        minWidth = 0
        minimumWidth = 0
        setOnClickListener { onClick() }
    }

    private fun hrow(vararg views: android.view.View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for (v in views) addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    }

    private fun service(): AgentAccessibilityService? {
        val s = AgentAccessibilityService.instance
        if (s == null) toast("Pehle Accessibility me LoRA ko on karo")
        return s
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TaskStore.recoverOnStart(this)
        val pad = dp(16)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        val title = TextView(this).apply {
            text = "LoRA v0.5"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
        }
        val btnChat = Button(this).apply {
            text = "💬 Chat kholo (history phone me, offline)"
            setOnClickListener { startActivity(Intent(this@MainActivity, ChatActivity::class.java)) }
        }

        // ---- Dashboard ----
        dash = TextView(this).apply {
            textSize = 13f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Ui.rounded(Color.parseColor("#E8F0FE"), dp(12))
        }
        val dashRow1 = hrow(
            btn("⏸ Pause") { if (AgentLoop.isRunning()) AgentLoop.setPaused(true) else toast("Agent chal nahi raha") },
            btn("▶ Resume") { resumeAgent() },
            btn("Skip") { AgentLoop.skip() },
            btn("Next") { AgentLoop.next() }
        )
        val dashRow2 = hrow(
            btn("■ Stop") { AgentLoop.stop() },
            btn("Edit steps") { service()?.showStepsEditor() },
            btn("💬 Chat") { startActivity(Intent(this, ChatActivity::class.java)) }
        )

        // ---- Setup ----
        val btnAccess = Button(this).apply {
            text = "1. Accessibility settings kholo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val bubbleSwitch = Switch(this).apply {
            text = "Floating icon dikhao"
            isChecked = Config.bubbleEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Config.setBubble(this@MainActivity, on) }
        }
        val btnIcon = btn("Floating icon wapas dikhao (Close ke baad)") { AgentAccessibilityService.instance?.showIcon() }

        // ---- Goal ----
        val goal = EditText(this).apply {
            hint = "Goal ya (agent chal raha ho to) message"
            minLines = 2
        }
        val btnStart = Button(this).apply {
            text = "2. Agent start / message bhejo"
            setOnClickListener {
                val svc = service() ?: return@setOnClickListener
                val g = goal.text.toString().trim()
                if (g.isEmpty()) {
                    toast("Goal likho")
                    return@setOnClickListener
                }
                if (Config.load(this@MainActivity).isEmpty()) {
                    toast("Pehle koi provider ya local model jodo")
                    return@setOnClickListener
                }
                AgentLoop.submit(svc, g)
            }
        }

        // ---- Step execution mode ----
        stepsField = EditText(this).apply {
            hint = "Custom steps"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Config.maxSteps(this@MainActivity).toString())
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val n = s?.toString()?.toIntOrNull() ?: return
                    if (n > 0) Config.setMaxSteps(this@MainActivity, n)
                }
            })
        }
        val unlimitedSwitch = Switch(this).apply {
            text = "♾ Unlimited steps (loop se bachne ki safety on rehti hai)"
            isChecked = Config.unlimited(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                Config.setUnlimited(this@MainActivity, on)
                stepsField.isEnabled = !on
            }
        }
        stepsField.isEnabled = !Config.unlimited(this)
        val quick = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            for (n in Config.STEP_CHOICES) {
                addView(btn("$n") {
                    Config.setUnlimited(this@MainActivity, false)
                    Config.setMaxSteps(this@MainActivity, n)
                    unlimitedSwitch.isChecked = false
                    stepsField.setText(n.toString())
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
        }
        val manualSwitch = Switch(this).apply {
            text = "✋ Manual step: har step se pehle poochho (Chalao/Skip/Roko)"
            isChecked = Config.manualStep(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Config.setManualStep(this@MainActivity, on) }
        }
        val cpField = EditText(this).apply {
            hint = "Auto checkpoint har N step par (0 = band)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Config.autoCheckpoint(this@MainActivity).toString())
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val n = s?.toString()?.toIntOrNull() ?: return
                    Config.setAutoCheckpoint(this@MainActivity, n)
                }
            })
        }

        // ---- Data processing ----
        val dataGroup = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            val opts = listOf(
                "local" to "🟢 Sirf Local (kuch bhi online nahi jayega)",
                "ask" to "❓ Online se pehle poochho (default)",
                "allow" to "🌐 Online allowed"
            )
            for ((k, label) in opts) {
                val rb = RadioButton(this@MainActivity).apply {
                    text = label
                    id = android.view.View.generateViewId()
                    isChecked = Config.dataMode(this@MainActivity) == k
                    setOnClickListener {
                        Config.setDataMode(this@MainActivity, k)
                        Privacy.session = false
                    }
                }
                addView(rb)
            }
        }

        // ---- Voice ----
        val ttsSwitch = Switch(this).apply {
            text = "Chat ke jawab bolkar sunao (TTS)"
            isChecked = Config.ttsOn(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Config.setTts(this@MainActivity, on) }
        }
        val speakGroup = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            val opts = listOf(
                "silent" to "🔇 Silent (agent kuch nahi bolega)",
                "important" to "❗ Sirf zaruri baatein (permission, error, pause, done)",
                "every" to "🗣 Har step bolo"
            )
            for ((k, label) in opts) {
                addView(RadioButton(this@MainActivity).apply {
                    text = label
                    id = android.view.View.generateViewId()
                    isChecked = Config.speakMode(this@MainActivity) == k
                    setOnClickListener { Config.setSpeakMode(this@MainActivity, k) }
                })
            }
        }
        val rateBar = SeekBar(this).apply {
            max = 15
            progress = ((Config.ttsRate(this@MainActivity) - 0.5f) / 0.1f).toInt().coerceIn(0, 15)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) Config.setTtsRate(this@MainActivity, 0.5f + p * 0.1f)
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        val volBar = SeekBar(this).apply {
            max = 9
            progress = ((Config.ttsVolume(this@MainActivity) * 10f).toInt() - 1).coerceIn(0, 9)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) Config.setTtsVolume(this@MainActivity, (p + 1) / 10f)
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        langBtn = Button(this).apply {
            setOnClickListener {
                val i = Config.LANGS.indexOf(Config.voiceLang(this@MainActivity))
                Config.setVoiceLang(this@MainActivity, Config.LANGS[(i + 1) % Config.LANGS.size])
                refreshButtons()
            }
        }
        val voiceBtn = btn("Awaaz (voice) chuno") { pickVoice() }
        val testBtn = btn("Test: bolkar sunao") {
            Speaker.speak(this, "Namaste, main LoRA hu. Ye meri awaaz ka test hai.")
        }

        // ---- Model ----
        modelBtn = Button(this).apply {
            setOnClickListener {
                ModelPicker.show(this@MainActivity, false) { runOnUiThread { refreshButtons() } }
            }
        }

        // ---- Providers ----
        providersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val keyField = EditText(this).apply {
            hint = "API key (Gemini AIza... / OpenRouter sk-or-... / Groq gsk_... / custom)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val modelsField = EditText(this).apply {
            hint = "Model(s), comma se. Khali = auto (Gemini/OpenRouter)"
        }
        val baseField = EditText(this).apply {
            hint = "Base URL (sirf custom provider ke liye)"
        }
        val addBtn = Button(this).apply {
            text = "+ Cloud provider jodo"
            setOnClickListener {
                val key = keyField.text.toString().trim()
                if (key.isEmpty()) {
                    toast("API key daalo")
                    return@setOnClickListener
                }
                val type = Config.detectType(key)
                val base = if (type == "custom") baseField.text.toString().trim()
                else Config.presetBase(type)
                val models = Config.splitModels(modelsField.text.toString())
                if (type == "custom" && base.isEmpty()) {
                    toast("Is key ke liye Base URL chahiye")
                    return@setOnClickListener
                }
                if ((type == "groq" || type == "custom") && models.isEmpty()) {
                    toast("Is provider ke liye model ka naam do")
                    return@setOnClickListener
                }
                if (models.any { it.contains(' ') }) {
                    toast("Model ka slug likho (jaise vendor/model-name), display name nahi")
                    return@setOnClickListener
                }
                val list = Config.load(this@MainActivity).filter { it.key != key } +
                    Provider(type, key, base, models)
                Config.save(this@MainActivity, list)
                keyField.setText("")
                modelsField.setText("")
                baseField.setText("")
                refreshProviders()
                toast("Jod diya: $type")
            }
        }

        // ---- Local / Ollama (offline model) ----
        val localBase = EditText(this).apply {
            hint = "Local URL: http://127.0.0.1:11434/v1  (ya https://tumhara-server/v1)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val localModel = EditText(this).apply {
            hint = "Model(s), comma se (jaise llama3.2:3b, qwen2.5:1.5b)"
        }
        val localKey = EditText(this).apply {
            hint = "API key (zarurat ho to, warna khali)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val addLocal = Button(this).apply {
            text = "+ Local model jodo"
            setOnClickListener {
                val base = localBase.text.toString().trim().trimEnd('/')
                val models = Config.splitModels(localModel.text.toString())
                val key = localKey.text.toString().trim()
                if (!(base.startsWith("http://") || base.startsWith("https://"))) {
                    toast("URL http:// ya https:// se shuru karo")
                    return@setOnClickListener
                }
                val host = Uri.parse(base).host.orEmpty()
                if (base.startsWith("http://") && host !in listOf("localhost", "127.0.0.1", "10.0.2.2")) {
                    toast("http:// sirf localhost / 127.0.0.1 par chalta hai. Dusre server ke liye https:// URL do")
                    return@setOnClickListener
                }
                if (models.isEmpty()) {
                    toast("Model ka naam do")
                    return@setOnClickListener
                }
                if (models.any { it.contains(' ') }) {
                    toast("Model ka slug likho, display name nahi")
                    return@setOnClickListener
                }
                val list = Config.load(this@MainActivity)
                    .filter { !(it.type == "local" && it.baseUrl == base) } +
                    Provider("local", key, base, models)
                Config.save(this@MainActivity, list)
                localBase.setText("")
                localModel.setText("")
                localKey.setText("")
                refreshProviders()
                toast("Local model jod diya")
            }
        }

        tasksBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        logView = TextView(this).apply {
            textSize = 13f
            setPadding(0, pad, 0, 0)
        }

        page.addView(title)
        page.addView(btnChat)
        page.addView(hrow(
            btn("🧩 Skill Studio") { startActivity(Intent(this, SkillsActivity::class.java)) },
            btn("🕘 Agent History") { startActivity(Intent(this, HistoryActivity::class.java)) }
        ))
        page.addView(btn("🤖 Doosre AI app (ChatGPT/Gemini...) se poochho") { Platforms.askDialog(this) })

        page.addView(heading("AGENT"))
        page.addView(dash)
        page.addView(dashRow1)
        page.addView(dashRow2)

        page.addView(heading("Setup"))
        page.addView(btnAccess)
        page.addView(bubbleSwitch)
        page.addView(btnIcon)

        page.addView(heading("Agent chalao"))
        page.addView(goal)
        page.addView(btnStart)

        page.addView(heading("Step Execution Mode"))
        page.addView(quick)
        page.addView(stepsField)
        page.addView(unlimitedSwitch)
        page.addView(manualSwitch)
        page.addView(cpField)
        page.addView(note("Chalte agent par bhi floating window se badal sakte ho. Unlimited me loop pakadne wali safety on rehti hai."))

        page.addView(heading("Data Processing"))
        page.addView(dataGroup)
        page.addView(note("Default: online se pehle poochho. Local model hamesha pehle use hota hai."))

        page.addView(heading("Awaaz"))
        page.addView(ttsSwitch)
        page.addView(speakGroup)
        page.addView(note("Speech speed"))
        page.addView(rateBar)
        page.addView(note("Volume"))
        page.addView(volBar)
        page.addView(langBtn)
        page.addView(voiceBtn)
        page.addView(testBtn)

        page.addView(heading("Model Manager"))
        page.addView(modelBtn)
        page.addView(note("Beech me model badlo to chat/agent ka kaam wahin se chalta rahega."))

        page.addView(heading("Providers (limit/error par agla apne aap)"))
        page.addView(providersBox)
        page.addView(keyField)
        page.addView(modelsField)
        page.addView(baseField)
        page.addView(addBtn)

        page.addView(heading("Local / offline model (Ollama, llama.cpp server)"))
        page.addView(note("Local model pehle use hota hai; internet na ho tab bhi chalega."))
        page.addView(localBase)
        page.addView(localModel)
        page.addView(localKey)
        page.addView(addLocal)

        page.addView(heading("Tasks (local history)"))
        page.addView(tasksBox)
        page.addView(heading("Skills"))
        page.addView(note("Skills banao / edit / update / merge karne ke liye Skill Studio kholo."))
        page.addView(btn("🧩 Skill Studio kholo") { startActivity(Intent(this, SkillsActivity::class.java)) })

        page.addView(heading("Log"))
        page.addView(logView)

        setContentView(
            ScrollView(this).apply {
                addView(
                    page,
                    ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                )
            }
        )
        refreshProviders()
        refreshButtons()
    }

    // ---------- actions ----------

    private fun resumeAgent() {
        if (AgentLoop.isRunning()) {
            AgentLoop.setPaused(false)
            return
        }
        val svc = service() ?: return
        val tk = TaskStore.unfinished(this)
        if (tk == null) toast("Koi adhura task nahi") else AgentLoop.resumeTask(svc, tk.id, null)
    }

    private fun pickVoice() {
        Speaker.listVoices(this) { names ->
            val all = listOf("(Default voice)") + names
            AlertDialog.Builder(this)
                .setTitle("Awaaz chuno (${Config.voiceLang(this)})")
                .setItems(all.toTypedArray()) { _, i ->
                    Config.setTtsVoice(this, if (i == 0) null else names[i - 1])
                    Speaker.speak(this, "Ye meri awaaz hai.")
                }
                .setNegativeButton("Band", null)
                .show()
        }
    }

    private fun checkRecovery() {
        if (recoveryShown) return
        recoveryShown = true
        val t = TaskStore.interrupted(this) ?: return
        AlertDialog.Builder(this)
            .setTitle("Adhura Agent task mila")
            .setMessage("Task #${t.id}: ${t.goal.take(80)}\nStep ${t.step} tak ho chuka tha.")
            .setPositiveButton("Continue") { _, _ ->
                val svc = service() ?: return@setPositiveButton
                AgentLoop.resumeTask(svc, t.id, null)
            }
            .setNeutralButton("Restart") { _, _ ->
                val svc = service() ?: return@setNeutralButton
                TaskStore.reset(this, t.id)
                AgentLoop.resumeTask(svc, t.id, null)
            }
            .setNegativeButton("Delete") { _, _ ->
                TaskStore.discard(this, t.id)
                refreshTasks()
            }
            .show()
    }

    // ---------- refresh ----------

    private fun refreshDashboard() {
        val running = AgentLoop.isRunning()
        val tk = if (AgentLoop.taskId > 0) TaskStore.get(this, AgentLoop.taskId)
        else TaskStore.unfinished(this) ?: TaskStore.latest(this)
        val state = when (AgentState.status) {
            Status.IDLE -> "⚪ Idle"
            Status.RUNNING -> "🟢 Running"
            Status.WAITING -> "🟡 Waiting"
            Status.PAUSED -> "🔵 Paused"
            Status.ERROR -> "🔴 Error"
        }
        val step = if (running) AgentLoop.step else (tk?.step ?: 0)
        dash.text = "Current Task: ${tk?.goal?.take(70) ?: "—"}\n" +
            "Status: $state (${tk?.status ?: "-"})\n" +
            "Progress: $step / ${AgentLoop.totalLabel(this)}\n" +
            "Current Step: ${AgentState.detail}\n" +
            "Model: ${ModelPicker.shortLabel(this)}  ${Privacy.activeLabel(this)}\n" +
            "Checkpoint: Step ${tk?.checkpoint ?: 0}"
    }

    private fun refreshButtons() {
        modelBtn.text = "Model: ${ModelPicker.shortLabel(this)}  ▾   ${Privacy.activeLabel(this)}"
        langBtn.text = "Bolne ki bhasha: ${Config.voiceLang(this)} (badalne ke liye dabao)"
        refreshDashboard()
    }

    private fun refreshTasks() {
        tasksBox.removeAllViews()
        val list = TaskStore.recent(this, 6)
        if (list.isEmpty()) {
            tasksBox.addView(TextView(this).apply { text = "(abhi koi task nahi)" })
            return
        }
        for (t in list) {
            val info = TextView(this).apply {
                text = "#${t.id} ${t.goal.take(40)}\n   ${t.status} · step ${t.step}"
                textSize = 13f
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(4), 0, dp(4))
            }
            row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (t.status != "completed") row.addView(btn("Resume") {
                val svc = service() ?: return@btn
                AgentLoop.resumeTask(svc, t.id, null)
            })
            row.addView(btn("Hatao") {
                TaskStore.discard(this, t.id)
                refreshTasks()
            })
            tasksBox.addView(row)
        }
    }

    private fun refreshProviders() {
        providersBox.removeAllViews()
        val list = Config.load(this)
        if (list.isEmpty()) {
            providersBox.addView(TextView(this).apply { text = "(abhi koi provider nahi)" })
            return
        }
        for ((i, p) in list.withIndex()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(4), 0, dp(4))
            }
            val models = if (p.models.isEmpty()) "auto" else p.models.joinToString(", ")
            val info = TextView(this).apply {
                text = "${i + 1}. ${if (p.type == "local") "🟢" else "🌐"} ${p.label}\n    $models"
                textSize = 13f
            }
            val up = btn("↑") {
                if (i > 0) {
                    val m = list.toMutableList()
                    val t = m[i]
                    m[i] = m[i - 1]
                    m[i - 1] = t
                    Config.save(this, m)
                    refreshProviders()
                }
            }
            val del = btn("Hatao") {
                val pin = Config.pin(this)
                if (pin != null && pin.startsWith(Pool.pinId(p, ""))) Config.setPin(this, null)
                Config.save(this, list.filterIndexed { idx, _ -> idx != i })
                refreshProviders()
                refreshButtons()
            }
            row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(up)
            row.addView(del)
            providersBox.addView(row)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshProviders()
        refreshButtons()
        refreshTasks()
        logView.text = AgentLog.lines.joinToString("\n")
        AgentLog.addListener(logListener)
        AgentState.addListener(stateListener)
        checkRecovery()
    }

    override fun onPause() {
        super.onPause()
        AgentLog.removeListener(logListener)
        AgentState.removeListener(stateListener)
    }
}
